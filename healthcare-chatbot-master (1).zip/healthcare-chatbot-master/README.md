# healthcare-chatbot
## Important Note !!
Please note that the project is no longer maintained. 
If anyone wants to expand it further, simply clone it to your own local , make changes and push to your own github account. 

Thanks all !!! 

a chatbot based on sklearn where you can give a symptom and it will ask you questions and will tell you the details and give some advice.
